## Overview

Add a runnable sizing example for a single-node E+PD deployment with one GPU
per worker. Given a GPU budget and measured encoder and combined prefill/decode
rates, report the recommended split, estimated capacity, and bottleneck.

Refs [#67204](https://github.com/vllm-project/vllm/issues/67204) and the
[EPD tracker](https://github.com/vllm-project/vllm/issues/52409). A search of
open PRs for EPD sizing, planning, and references to #67204 found related
proxy and connector changes. This example addresses replica sizing.

## Claims

- The example evaluates each split using the smaller of the two estimated
  aggregate worker rates and reports the highest-capacity split.
- The documentation describes how to measure isolated stage saturation and
  check the estimate using independent requests.

## Validation

```bash
python examples/disaggregated/disaggregated_encoder/size_epd.py \
  --num-gpus 8 --encoder-rps 57 --pd-rps 14.3
```

Expected result is `2E+6PD`, with an estimated `85.8 req/s` and PD as the
bottleneck. This reproduces the worked arithmetic with reported input rates.

For the SuperPOD replay, use four H800 GPUs on one node and vLLM `v0.33.0`
at revision `4ba787ec9959e566d3b587a796dff07673324da5`. The workload uses
one synthetic image per request, Qwen2.5-VL-3B-Instruct, an encoder batch
cap of one, and a fresh EC cache and service processes for every pressure run.
The calibration and validation requests use disjoint random seeds.

```bash
sbatch epd-sizing-67204.sbatch
# Or run the same experiment on Linux with that vLLM version active and four visible GPUs.
python run_epd_sizing_experiment.py --repo /path/to/vllm-v0.33.0 \
  --sizer /path/to/pr/examples/disaggregated/disaggregated_encoder/size_epd.py \
  --output ./epd-sizing-results
```

The harness records launch arguments, load parameters and seeds, raw completion
counters, and client results. `calibration.json` contains the saturation
measurements. The harness writes and hashes `frozen-plan.json` before launching
the three splits at each held-out offered load. `validation.json` records the
result for each split and the frozen plan hash.

<!-- SUPERPOD_VALIDATION -->

The same reproducer also runs a workload-shift check when its bundled
`frozen_predictor/` directory is present. The archived predictor and calibration
are research artifacts for this validation. The CLI example takes measured E and
PD service rates directly.

<!-- SHIFT_VALIDATION -->

## Details

The sizing rule is described in §3 of *Provision Before You Serve: Computing
the E:PD Ratio for Disaggregated Multimodal LLM Serving*, accepted at FAISys.
The workload-shift check studies whether one calibration can supply rates for
different request mixes within its encoder token range and under the same serving
configuration. The archived model recomputes rates from merged encoder tokens
and paired PD input/output lengths. The baseline keeps the two rates measured
for the original request mix. The held-out sweep tests both recommendations.

---

<details>
<summary> Pull Request Checklist </summary>

- [x] I used vLLM's `/pr-checklist` skill.
- [x] AI assistance was used during the creation of this PR.
- [x] **Design Fit:** Example and documentation changes only.
- [ ] **Testing and Validation:** Submitting human ran relevant tests and reviewed the GPU validation.
- [ ] **Code Quality and Style:** Submitting human reviewed all changed lines.
- [ ] **Pull Request Contents:** Add the complete SuperPOD results and reproducer.
</details>

**BEFORE SUBMITTING, PLEASE READ <https://docs.vllm.ai/en/latest/contributing>**
