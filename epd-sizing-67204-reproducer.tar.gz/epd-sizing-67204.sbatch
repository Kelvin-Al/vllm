#!/usr/bin/env bash
#SBATCH --job-name=epd-sizing-67204
#SBATCH --account=zijieieda26
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-node=4
#SBATCH --time=02:00:00
#SBATCH --output=epd-sizing-%j.out

set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
export PYTHONUNBUFFERED=1 HF_HUB_DISABLE_TELEMETRY=1 VLLM_NO_USAGE_STATS=1
export VLLM_ENABLE_CUDA_COMPATIBILITY=0 APPTAINERENV_VLLM_ENABLE_CUDA_COMPATIBILITY=0
export HF_HOME="${EPD_HF_CACHE:-/scratch/zijieieda26/epd-smoke-15iX8F/hf-cache}"
image="${EPD_SIF:-/scratch/zijieieda26/slyual-epd-plan-PSmjqp/vllm-v0.33.0.sif}"
if [[ "${EPD_IN_CONTAINER:-0}" != 1 ]]; then
    source /etc/profile.d/modules.sh
    module load apptainer
    exec apptainer exec --nv --bind "$PWD:$PWD" --bind "$HF_HOME:$HF_HOME" \
        "$image" env EPD_IN_CONTAINER=1 bash epd-sizing-67204.sbatch
fi

nvidia-smi --query-gpu=index,name,driver_version --format=csv
vllm --version
cat vllm-source-revision.txt
python3 run_epd_sizing_experiment.py --repo "$PWD" --sizer "$PWD/size_epd.py" \
    --output "$PWD/results-${SLURM_JOB_ID:?}"
