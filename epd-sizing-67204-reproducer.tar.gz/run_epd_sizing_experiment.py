"""Measure E and PD independently, then validate a frozen four-GPU plan."""

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from statistics import fmean

from summarize_epd_superpod import observe_metrics


def write_json(path, payload):
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def report(calibration, plan, digest, validation):
    split = f"{plan['encoder_gpus']}E+{plan['pd_gpus']}PD"
    lines = [
        "### SuperPOD independent calibration and held-out validation",
        "",
        "| Stage | Offered req/s | Single-worker completions/s |",
        "| --- | ---: | ---: |",
    ]
    for stage, runs in calibration.items():
        for run in runs:
            lines.append(
                f"| {stage} | {run['offered_rps']} | {run[f'{stage}_rps']:.2f} |"
            )
    lines += [
        "",
        (
            f"The mean measured inputs were {plan['encoder_rps']:.2f} req/s for E "
            f"and {plan['pd_rps']:.2f} req/s for PD. The frozen recommendation was "
            f"`{split}` at {plan['predicted_capacity_rps']:.2f} req/s, "
            f"with `{plan['bottleneck']}` as the estimated bottleneck."
        ),
        "",
        f"Frozen plan SHA-256 `{digest}`.",
        "",
        "| Offered req/s | Split | Estimated capacity | PD completions/s | Client req/s | Completed |",
        "| ---: | --- | ---: | ---: | ---: | ---: |",
    ]
    capacities = {
        row["encoder_gpus"]: row["predicted_capacity_rps"]
        for row in plan["candidate_allocations"]
    }
    for run in validation:
        e, pd = run["encoder_gpus"], run["pd_gpus"]
        lines.append(
            f"| {run['offered_rps']} | {e}E+{pd}PD | {capacities[e]:.2f} | "
            f"{run['pd_rps']:.2f} | {run['client_throughput_rps']:.2f} | "
            f"{run['completed']} |"
        )
    lines.append("")
    for offered in sorted({run["offered_rps"] for run in validation}):
        observed = {
            run["encoder_gpus"]: run["pd_rps"]
            for run in validation
            if run["offered_rps"] == offered
        }
        best = max(observed, key=observed.get)
        selected = plan["encoder_gpus"]
        lines.append(
            f"- At {offered} offered req/s, the recommended split achieved "
            f"{observed[selected]:.2f} req/s "
            f"(capacity estimate error {capacities[selected] / observed[selected] - 1:+.1%}). "
            f"The fastest tested split was `{best}E+{4 - best}PD` at {observed[best]:.2f} req/s."
        )
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--sizer", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True)
    runner = Path(__file__).with_name("run_epd_superpod.py")

    def measure(label, encoder, pd, offered, seed, saturated_stage=None, **shape):
        wave = {
            "name": "wave",
            "rate": offered,
            "prompts": 960,
            "seed": seed,
            "input_len": 128,
            "output_len": 48,
            "range_ratio": 0.25,
            "buckets": "{(1400, 1400, 1): 0.45, (1736, 1736, 1): 0.35, (2072, 2072, 1): 0.20}",
            **shape,
        }
        wave_path = args.output / f"{label}-waves.json"
        write_json(wave_path, [wave])
        dest = args.output / label
        command = [
            sys.executable,
            str(runner),
            "--repo",
            str(args.repo),
            "--output",
            str(dest),
            "--waves",
            str(wave_path),
            "--encoders",
            str(encoder),
            "--pd",
            str(pd),
            "--encoder-max-seqs",
            "1",
            "--pd-kv-bytes",
            "1073741824",
            "--pd-chunk",
            "512",
            "--model",
            "Qwen/Qwen2.5-VL-3B-Instruct",
        ]
        write_json(args.output / f"{label}-command.json", command)
        subprocess.run(command, check=True)
        bench = read_json(dest / "wave.json")
        if bench["failed"] or bench["completed"] != wave["prompts"]:
            raise ValueError(f"{label} did not complete every request")
        duration = read_json(dest / "wave-window.json")["offered_seconds"]
        metrics = observe_metrics(dest / "wave-metrics.jsonl", duration)
        if len(metrics) != encoder + pd:
            raise ValueError(f"{label} has incomplete worker metrics")
        samples = [values for _, values in sorted(metrics.items())]
        e_samples, pd_samples = samples[:encoder], samples[encoder:]
        if saturated_stage:
            target, peer = (
                (e_samples, pd_samples)
                if saturated_stage == "encoder"
                else (pd_samples, e_samples)
            )
            if target[0][1] < 1 or any(sample[1] >= 1 for sample in peer):
                raise ValueError(
                    f"{label} did not isolate the {saturated_stage} bottleneck: {samples}"
                )
        return {
            "encoder_gpus": encoder,
            "pd_gpus": pd,
            "offered_rps": offered,
            "seed": seed,
            "encoder_rps": sum(row[0] for row in e_samples),
            "pd_rps": sum(row[0] for row in pd_samples),
            "encoder_waiting_per_worker": [row[1] for row in e_samples],
            "pd_waiting_per_worker": [row[1] for row in pd_samples],
            "client_throughput_rps": bench["request_throughput"],
            "completed": bench["completed"],
        }

    calibration = {}
    for stage, e, pd, loads in (("encoder", 1, 3, (20, 25)), ("pd", 3, 1, (16, 20))):
        calibration[stage] = [
            measure(f"calibrate-{stage}-{rate}", e, pd, rate, seed, stage)
            for rate, seed in zip(loads, (6720401, 6720402), strict=True)
        ]
        rates = [row[f"{stage}_rps"] for row in calibration[stage]]
        if max(rates) - min(rates) > 0.15 * fmean(rates):
            raise ValueError(
                f"{stage} calibration did not reach a stable plateau: {rates}"
            )
    write_json(args.output / "calibration.json", calibration)
    e_rate = fmean(row["encoder_rps"] for row in calibration["encoder"])
    pd_rate = fmean(row["pd_rps"] for row in calibration["pd"])
    command = [
        sys.executable,
        str(args.sizer),
        "--num-gpus",
        "4",
        "--encoder-rps",
        str(e_rate),
        "--pd-rps",
        str(pd_rate),
    ]
    write_json(args.output / "plan-command.json", command)
    plan_path = args.output / "frozen-plan.json"
    plan_path.write_text(subprocess.check_output(command, text=True), encoding="utf-8")
    digest = hashlib.sha256(plan_path.read_bytes()).hexdigest()
    (args.output / "frozen-plan.sha256").write_text(digest + "\n", encoding="utf-8")
    validation = []
    for rate, seed in ((25, 6720411), (31, 6720412)):
        reference_lengths = None
        for e in (1, 2, 3):
            label = f"validate-{e}e-{4 - e}pd-{rate}"
            validation.append(measure(label, e, 4 - e, rate, seed, None))
            bench = read_json(args.output / label / "wave.json")
            lengths = list(zip(bench["input_lens"], bench["output_lens"], strict=True))
            if reference_lengths is None:
                reference_lengths = lengths
            elif lengths != reference_lengths:
                raise ValueError(f"{label} changed the held-out request lengths")
            write_json(
                args.output / "validation.json",
                {"plan_sha256": digest, "runs": validation},
            )
    if hashlib.sha256(plan_path.read_bytes()).hexdigest() != digest:
        raise RuntimeError("The recommendation changed during validation")
    validation_text = report(calibration, read_json(plan_path), digest, validation)
    (args.output / "validation.md").write_text(validation_text, encoding="utf-8")
    pr_template = Path(__file__).with_name("epd-sizing-pr-67204.md")
    if pr_template.is_file():
        body = pr_template.read_text(encoding="utf-8").replace(
            "<!-- SUPERPOD_VALIDATION -->", validation_text
        )
        (args.output / "pr-body.md").write_text(body, encoding="utf-8")

    if Path(__file__).with_name("frozen_predictor").is_dir():
        from validate_epd_shift import validate_shift

        shift_report = validate_shift(
            args.output, measure, read_json(plan_path), args.sizer
        )
        if pr_template.is_file():
            (args.output / "pr-body.md").write_text(
                body.replace("<!-- SHIFT_VALIDATION -->", shift_report),
                encoding="utf-8",
            )


if __name__ == "__main__":
    main()
