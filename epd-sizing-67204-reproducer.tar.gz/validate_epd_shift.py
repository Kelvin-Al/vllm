"""Check a frozen workload model on a shifted E+PD request distribution."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

from run_epd_sizing_experiment import read_json, write_json

FROZEN_SHA256 = "91e22357828838743e77796a0eae05bb0e9cc0ed54fb46eaf06e04e2a63025ec"


def validate_shift(output, measure, previous, sizer):
    from PIL import Image
    from transformers import AutoImageProcessor

    import vllm.benchmarks

    predictor = Path(__file__).with_name("frozen_predictor")
    vllm.benchmarks.__path__.append(str(predictor))
    from vllm.benchmarks.epd_capture import pd_rate_bounds
    from vllm.benchmarks.epd_demand import workload_rates

    frozen = predictor / "frozen.json"
    if hashlib.sha256(frozen.read_bytes()).hexdigest() != FROZEN_SHA256:
        raise ValueError("The preexisting calibration hash changed")
    model = read_json(frozen)
    processor = AutoImageProcessor.from_pretrained(model["deployment"]["model"])
    metadata = processor(Image.new("RGB", (1400, 1400)), return_tensors="pt")
    t, h, w = metadata["image_grid_thw"][0].tolist()
    merged = t * h * w // processor.merge_size**2
    if merged != 2500:
        raise ValueError(f"The image produces {merged} merged tokens, expected 2500")

    shape = {"buckets": "{(1400, 1400, 1): 1.0}", "output_len": 128}
    measure("shift-shape-sample", 1, 1, 2, 6720420, prompts=96, **shape)
    sample = read_json(output / "shift-shape-sample" / "wave.json")
    pd_data = {key: sample[key] for key in ("input_lens", "output_lens", "failed")}
    requests = [{"visual_tokens": merged}] * sample["completed"]
    workload = {"encoder": requests, "pd": pd_data}
    workload_path = output / "shift-workload.json"
    write_json(workload_path, workload)
    pd_low, pd_high = pd_rate_bounds(pd_data, model["pd"])
    rates = workload_rates(model["encoder"], requests, pd_low)
    e_rate = rates["e_rate_upper_bound_rps"]
    command = [
        sys.executable,
        str(sizer),
        "--num-gpus",
        "4",
        "--encoder-rps",
        str(e_rate),
        "--pd-rps",
        str(pd_low),
    ]
    write_json(output / "shift-plan-command.json", command)
    recommendation = json.loads(subprocess.check_output(command, text=True))
    recommended = recommendation["encoder_gpus"]
    capacities = {
        row["encoder_gpus"]: row["predicted_capacity_rps"]
        for row in recommendation["candidate_allocations"]
    }
    plan = {
        "frozen_model_sha256": FROZEN_SHA256,
        "workload_sha256": hashlib.sha256(workload_path.read_bytes()).hexdigest(),
        "frozen_model_rates": rates,
        "pd_interval": [pd_low, pd_high],
        "shift_recommended_encoder_gpus": recommended,
        "shift_predicted_capacity_rps": capacities[recommended],
        "old_distribution_plan": previous,
    }
    plan_path = output / "shift-frozen-plan.json"
    write_json(plan_path, plan)
    plan_sha = hashlib.sha256(plan_path.read_bytes()).hexdigest()
    (output / "shift-frozen-plan.sha256").write_text(plan_sha + "\n", encoding="utf-8")

    replay = []
    for offered, seed in ((20, 6720421), (25, 6720422)):
        lengths = None
        for e in (1, 2, 3):
            label = f"shift-validate-{e}e-{4 - e}pd-{offered}"
            run = measure(label, e, 4 - e, offered, seed, prompts=720, **shape)
            bench = read_json(output / label / "wave.json")
            pair = list(zip(bench["input_lens"], bench["output_lens"], strict=True))
            if lengths is not None and pair != lengths:
                raise ValueError(f"{label} changed the replay corpus")
            lengths = pair
            replay.append(run)
            write_json(
                output / "shift-validation.json",
                {"plan_sha256": plan_sha, "runs": replay},
            )
    if hashlib.sha256(frozen.read_bytes()).hexdigest() != FROZEN_SHA256:
        raise ValueError("The previous calibration changed during validation")
    if hashlib.sha256(plan_path.read_bytes()).hexdigest() != plan_sha:
        raise ValueError("The shift recommendation changed during validation")

    baseline = previous["encoder_gpus"]
    lines = [
        "### Workload shift with the same frozen calibration",
        "",
        (
            "The original mix used three image sizes and a mean target of 48 output "
            "tokens. The shifted mix used only 1400×1400 images (2500 merged tokens) "
            "and a mean target of 128 output tokens. Model, hardware, cache policy "
            "and serving configuration were fixed. We sampled joint prompt and output "
            "lengths with seed 6720420 and locked both recommendations before replay "
            "with held-out seeds 6720421 and 6720422."
        ),
        "",
        (
            f"The frozen model estimated E at {e_rate:.2f} req/s and PD at "
            f"{pd_low:.2f}–{pd_high:.2f} req/s per worker. It selected "
            f"`{recommended}E+{4 - recommended}PD` at {capacities[recommended]:.2f} req/s. "
            f"Reusing the original rates selected `{baseline}E+{4 - baseline}PD` "
            f"at {previous['predicted_capacity_rps']:.2f} req/s."
        ),
        "",
        f"Frozen model SHA-256 `{FROZEN_SHA256}`. Shift plan SHA-256 `{plan_sha}`.",
        "",
        "| Offered req/s | Split | Frozen estimate | Observed E req/s | Observed PD req/s |",
        "| ---: | --- | ---: | ---: | ---: |",
    ]
    for run in replay:
        e = run["encoder_gpus"]
        lines.append(
            f"| {run['offered_rps']} | {e}E+{4 - e}PD | {capacities[e]:.2f} | "
            f"{run['encoder_rps']:.2f} | {run['pd_rps']:.2f} |"
        )
    lines.append("")
    for offered in (20, 25):
        runs = {
            run["encoder_gpus"]: run for run in replay if run["offered_rps"] == offered
        }
        observed = {e: run["pd_rps"] for e, run in runs.items()}
        best = max(observed, key=observed.get)
        lines.append(
            f"- At {offered} offered req/s, `{best}E+{4 - best}PD` was fastest "
            f"at {observed[best]:.2f} req/s. The frozen recommendation achieved "
            f"{observed[recommended]:.2f} req/s and reusing the old rates achieved "
            f"{observed[baseline]:.2f} req/s. Frozen capacity error was "
            f"{(capacities[recommended] / observed[recommended] - 1):+.1%}."
        )
        for stage, worker_count, predicted in (
            ("encoder", 1, e_rate),
            ("pd", 3, pd_low),
        ):
            worker = runs[worker_count]
            if worker[f"{stage}_waiting_per_worker"][0] >= 1:
                observed_rate = worker[f"{stage}_rps"]
                lines.append(
                    f"  The backlogged single {stage} completed {observed_rate:.2f} req/s "
                    f"(frozen point estimate error {predicted / observed_rate - 1:+.1%})."
                )
    markdown = "\n".join(lines) + "\n"
    (output / "shift-validation.md").write_text(markdown, encoding="utf-8")
    return markdown
