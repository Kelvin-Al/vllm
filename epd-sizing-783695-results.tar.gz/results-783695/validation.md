### SuperPOD independent calibration and held-out validation

| Stage | Offered req/s | Single-worker completions/s |
| --- | ---: | ---: |
| encoder | 20 | 11.33 |
| encoder | 25 | 11.18 |
| pd | 16 | 6.58 |
| pd | 20 | 6.92 |

The mean measured inputs were 11.25 req/s for E and 6.75 req/s for PD. The frozen recommendation was `2E+2PD` at 13.50 req/s, with `pd` as the estimated bottleneck.

Frozen plan SHA-256 `37288277d97d8a5db9ac8ee028a0cd2576d25a3c5256e10b3956b3507b4ba51e`.

| Offered req/s | Split | Estimated capacity | PD completions/s | Client req/s | Completed |
| ---: | --- | ---: | ---: | ---: | ---: |
| 25 | 1E+3PD | 11.25 | 11.59 | 11.27 | 960 |
| 25 | 2E+2PD | 13.50 | 13.78 | 13.58 | 960 |
| 25 | 3E+1PD | 6.75 | 6.84 | 7.22 | 960 |
| 31 | 1E+3PD | 11.25 | 11.57 | 11.24 | 960 |
| 31 | 2E+2PD | 13.50 | 13.49 | 13.14 | 960 |
| 31 | 3E+1PD | 6.75 | 6.18 | 6.98 | 960 |

- At 25 offered req/s, the recommended split achieved 13.78 req/s (capacity estimate error -2.0%). The fastest tested split was `2E+2PD` at 13.78 req/s.
- At 31 offered req/s, the recommended split achieved 13.49 req/s (capacity estimate error +0.1%). The fastest tested split was `2E+2PD` at 13.49 req/s.
