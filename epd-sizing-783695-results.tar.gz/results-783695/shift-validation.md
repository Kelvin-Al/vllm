### Workload shift with the same frozen calibration

The original mix used three image sizes and a mean target of 48 output tokens. The shifted mix used only 1400×1400 images (2500 merged tokens) and a mean target of 128 output tokens. Model, hardware, cache policy and serving configuration were fixed. We sampled joint prompt and output lengths with seed 6720420 and locked both recommendations before replay with held-out seeds 6720421 and 6720422.

The frozen model estimated E at 17.04 req/s and PD at 4.57–5.06 req/s per worker. It selected `1E+3PD` at 13.70 req/s. Reusing the original rates selected `2E+2PD` at 13.50 req/s.

Frozen model SHA-256 `91e22357828838743e77796a0eae05bb0e9cc0ed54fb46eaf06e04e2a63025ec`. Shift plan SHA-256 `1930166cb592c7c9be7fedb7e4e3c6c6ade95f607701a44e5b46799e61d30c8e`.

| Offered req/s | Split | Frozen estimate | Observed E req/s | Observed PD req/s |
| ---: | --- | ---: | ---: | ---: |
| 20 | 1E+3PD | 13.70 | 16.44 | 13.82 |
| 20 | 2E+2PD | 9.14 | 20.27 | 9.10 |
| 20 | 3E+1PD | 4.57 | 20.20 | 4.46 |
| 25 | 1E+3PD | 13.70 | 16.35 | 13.08 |
| 25 | 2E+2PD | 9.14 | 23.95 | 8.85 |
| 25 | 3E+1PD | 4.57 | 23.95 | 4.33 |

- At 20 offered req/s, `1E+3PD` was fastest at 13.82 req/s. The frozen recommendation achieved 13.82 req/s and reusing the old rates achieved 9.10 req/s. Frozen capacity error was -0.8%.
  The backlogged single encoder completed 16.44 req/s (frozen point estimate error +3.6%).
  The backlogged single pd completed 4.46 req/s (frozen point estimate error +2.5%).
- At 25 offered req/s, `1E+3PD` was fastest at 13.08 req/s. The frozen recommendation achieved 13.08 req/s and reusing the old rates achieved 8.85 req/s. Frozen capacity error was +4.8%.
  The backlogged single encoder completed 16.35 req/s (frozen point estimate error +4.2%).
  The backlogged single pd completed 4.33 req/s (frozen point estimate error +5.5%).
